#include <gtkmm.h>

class Window : public Gtk::Window {
public:
  Gtk::VBox vbox;
  Gtk::Entry fName;
  Gtk::Entry lName;
  Gtk::Button button;
  Gtk::Label fNameTitle;
  Gtk::Label lNameTitle;
  Gtk::Label label;

  Window() {
    button.set_label("Combine names");
    button.set_sensitive(false);
    fNameTitle.set_text("First name:");
    lNameTitle.set_text("Last name:");

    vbox.pack_start(fNameTitle);
    vbox.pack_start(fName); //Add the widget entry to vbox
    vbox.pack_start(lNameTitle);
    vbox.pack_start(lName);
    vbox.pack_start(button); //Add the widget button to vbox
    vbox.pack_start(label);  //Add the widget label to vbox

    add(vbox);  //Add vbox to window
    show_all(); //Show all widgets

    fName.signal_changed().connect([this]() {
      if (fName.get_text().length() != 0 && lName.get_text().length() != 0) {
        button.set_sensitive(true);
      } else {
        button.set_sensitive(false);
      }
    });

    lName.signal_changed().connect([this]() {
      if (fName.get_text().length() != 0 && lName.get_text().length() != 0) {
        button.set_sensitive(true);
      } else {
        button.set_sensitive(false);
      }
    });

    fName.signal_activate().connect([this]() {

    });
    lName.signal_activate().connect([this]() {
    });

    button.signal_clicked().connect([this]() {
      label.set_text("Names combined: " + fName.get_text() + " " + lName.get_text());
    });
  }
};

int main() {
  Gtk::Main gtk_main;
  Window window;
  window.set_title("Oving 4-2");
  gtk_main.run(window);
}
